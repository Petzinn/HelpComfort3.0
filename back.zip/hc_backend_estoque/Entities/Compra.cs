namespace hc_backend_estoque.Entities
{
    public class Compra
    {
        public int Id { get; set; }
        public string Produto { get; set; }
        public string Valor { get; set; }
        
    }
}