namespace hc_backend_estoque.Entities
{
    public class Categoria
    {
        public int Id { get; set; }
        public string Modelo { get; set; }
        public string Tecido { get; set; }
    }
}