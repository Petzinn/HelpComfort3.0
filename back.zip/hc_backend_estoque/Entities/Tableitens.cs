namespace hc_backend_estoque.Entities
{
    public class Tableitens
    {
        public int Id { get; set; }
        public string Produtos2 { get; set; }
        public string Categoria3 { get; set; }
        
    }
}