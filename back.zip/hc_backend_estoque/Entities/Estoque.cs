namespace hc_backend_estoque.Entities
{
    public class Estoque
    {
        public int Id { get; set; }
        public string Produtos { get; set; }
        public string Fornecedores { get; set; }
    }
}