namespace hc_backend_estoque.Entities
{
    public class Produtos
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public decimal Preco { get; set; }
        public string Tamanho { get; set; }
        public int Estoque { get; set; } // Novo campo para a quantidade disponível
      
    }
}
