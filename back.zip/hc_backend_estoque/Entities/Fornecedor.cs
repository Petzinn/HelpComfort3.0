namespace hc_backend_estoque.Entities
{
    public class Fornecedor
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Produtos { get; set; }
        public int quantidade {get; set;}
    }
}