namespace hc_backend_estoque.Entities
{
    public class Transacao
    {
        public int Id { get; set; }
        public string email{get;set;}
        public string pais {get; set;}
        public string nome { get; set; }
        public string sobrenome { get; set; }
        public int cep { get; set; }
        public string endereco { get; set; }
        public int numero {get;set;} 
        public string complemento {get;set;}
        public string bairro {get;set;}
        public string cidade {get;set;}
        public string estado {get;set;}
        public string telefone {get;set;}
        public string formadp {get;set;}

    }
}