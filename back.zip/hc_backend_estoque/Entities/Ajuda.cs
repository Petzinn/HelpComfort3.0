namespace hc_backend_estoque.Entities
{
    public class Ajuda
    {
        public int Id { get; set; }
        public string titulo {get;set;}
        public string lugardeFala { get; set; }
        
    }
}