namespace hc_backend_estoque.Entities
{
    public class CompraFinalizada
    {
        public int Id { get; set; }
        public string Produto2 { get; set; }
        public string Valor2 { get; set; }
        
    }
}