using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace hc_backend_estoque.Context
{
    public class HelpDBContext : DbContext
    {

        public HelpDBContext(DbContextOptions<HelpDBContext> options)
     : base(options)
        {
        }
        public DbSet<Categoria> Categoria { get; set; }
        public DbSet<Clientes> Clientes { get; set; }
        public DbSet<Compra> Compra { get; set; }
        public DbSet<CompraFinalizada> CompraFinalizada { get; set; }
        public DbSet<Estoque> Estoque{ get; set; }
        public DbSet<Fornecedor> Fornecedor { get; set; }
         public DbSet<Funcionario> Funcionario { get; set; }
        public DbSet<Ajuda> Ajuda { get; set; }
        public DbSet<Produtos> Produtos { get; set; }
        public DbSet<Tableitens> TableItens { get; set; }
        public DbSet<Transacao> Transacao { get; set; }
        public DbSet<Login> Login { get; set;}

    }
}