using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;


namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TableitensController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public TableitensController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("Tabelas de Itens")]
        public async Task<IActionResult> ObterTodosOsItens()
        {
            var Tableitens = await _context.TableItens.ToListAsync();
            return Ok(Tableitens);
        }

        [HttpGet("Tableitens/{id}")]
        public async Task<IActionResult> ObterItemPorId(int id)
        {
            var Tableitens = await _context.TableItens.FindAsync(id);
            if (Tableitens == null)
                return NotFound($"Item com ID {id} não encontrado.");
            return Ok(Tableitens);
        }


        [HttpPost("Postar item")]
        public async Task<IActionResult> CriarItens([FromBody] Tableitens novoItem)
        {
            _context.TableItens.Add(novoItem);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterItemPorId), new { id = novoItem.Id }, novoItem);
        }

        [HttpPut("BuscarItem/{id}")]
        public async Task<IActionResult> AtualizarItem(int id, [FromBody] Tableitens itemAtualizado)
        {
            if (id != itemAtualizado.Id)
                return BadRequest("ID do item não corresponde aos dados fornecidos.");

            var itemExistente = await _context.TableItens.FindAsync(id);
            if (itemExistente == null)
                return NotFound($"Produto com ID {id} não encontrado.");

          
            itemExistente.Id = itemAtualizado.Id;
            itemExistente.Produtos2 = itemAtualizado.Produtos2;
            itemExistente.Categoria3 = itemAtualizado.Categoria3;
       

            await _context.SaveChangesAsync();
            return Ok(itemExistente);
        }

        [HttpDelete("Deletar Itens/{id}")]
        public async Task<IActionResult> ExcluirItens(int id)
        {
            var itens = await _context.TableItens.FindAsync(id);
            if (itens == null)
                return NotFound($"Item com ID {id} não encontrado.");

            _context.TableItens.Remove(itens);
            await _context.SaveChangesAsync();
            return NoContent();
        }


    }
}