using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AjudaController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public AjudaController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("Ajuda")]
        public async Task<IActionResult> ObterAjuda()
        {
            var ajuda = await _context.Ajuda.ToListAsync();
            return Ok(ajuda);
        }

        [HttpGet("Ajuda/{id}")]
        public async Task<IActionResult> ObterAjuda(int id)
        {
            var ajuda = await _context.Ajuda.FindAsync(id);
            if (ajuda == null)
                return NotFound($"Ajuda com ID {id} não encontrado.");
            return Ok(ajuda);
        }

        [HttpPost("ajuda")]
        public async Task<IActionResult> CriarAjuda([FromBody] Ajuda novaAjuda)
        {
            if (string.IsNullOrEmpty(novaAjuda.titulo) || string.IsNullOrEmpty(novaAjuda.lugardeFala))
            {
                return BadRequest("Título e descrição são obrigatórios.");
            }

            _context.Ajuda.Add(novaAjuda);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(ObterAjuda), new { id = novaAjuda.Id }, new 
            {
                success = true,
                message = "Solicitação de ajuda enviada com sucesso!",
                id = novaAjuda.Id
            });
        }

        [HttpPut("Ajuda/{id}")]
        public async Task<IActionResult> AtualizarAjuda(int id, [FromBody] Ajuda ajudaAtualizada)
        {
            if (id != ajudaAtualizada.Id)
                return BadRequest("ID da Ajuda não corresponde aos dados fornecidos.");

            var ajudaExistente = await _context.Ajuda.FindAsync(id);
            if (ajudaExistente == null)
                return NotFound($"Ajuda com ID {id} não encontrado.");

            ajudaExistente.titulo = ajudaAtualizada.titulo;
            ajudaExistente.lugardeFala = ajudaAtualizada.lugardeFala; // Certifique-se de que este campo existe na entidade.

            await _context.SaveChangesAsync();
            return Ok(ajudaExistente);
        }

        [HttpDelete("Ajuda/{id}")]
        public async Task<IActionResult> ExcluirAjuda(int id)
        {
            var ajuda = await _context.Ajuda.FindAsync(id);
            if (ajuda == null)
                return NotFound($"Ajuda com ID {id} não encontrado.");

            _context.Ajuda.Remove(ajuda);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
