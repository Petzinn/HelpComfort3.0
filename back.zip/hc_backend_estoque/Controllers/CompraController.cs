using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;


namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompraController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public CompraController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("Compra")]
        public async Task<IActionResult> ObterCompra()
        {
            var compra = await _context.Compra.ToListAsync();
            return Ok(compra);
        }

        [HttpGet("compra/{id}")]
        public async Task<IActionResult> ObterCompra(int id)
        {
            var compra = await _context.Compra.FindAsync(id);
            if (compra == null)
                return NotFound($"Compra com ID {id} não encontrado.");
            return Ok(compra);
        }


        [HttpPost("compra")]
        public async Task<IActionResult> ObterCompraPorId([FromBody] Compra novaCompra)
        {
            _context.Compra.Add(novaCompra);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterCompraPorId), new { id = novaCompra.Id }, novaCompra);
        }

        [HttpPut("compra/{id}")]
        public async Task<IActionResult> AtualizarCompra(int id, [FromBody] Compra CompraAtualizada)
        {
            if (id != CompraAtualizada.Id)
                return BadRequest("ID da Compra não corresponde aos dados fornecidos.");

            var compraExistente = await _context.Compra.FindAsync(id);
            if (compraExistente == null)
                return NotFound($"Compra com ID {id} não encontrado.");

          
            compraExistente.Id = CompraAtualizada.Id;
            compraExistente.Produto = CompraAtualizada.Produto;
            compraExistente.Valor = CompraAtualizada.Valor;
       

            await _context.SaveChangesAsync();
            return Ok(compraExistente);
        }

        [HttpDelete("compra/{id}")]
        public async Task<IActionResult> ExcluirCompra(int id)
        {
            var compra = await _context.Compra.FindAsync(id);
            if (compra == null)
                return NotFound($"Compra com ID {id} não encontrado.");

            _context.Compra.Remove(compra);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}