using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FornecedorController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public FornecedorController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> ObterFornecedores()
        {
            var fornecedores = await _context.Fornecedor.ToListAsync();
            return Ok(fornecedores);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> ObterFornecedor(int id)
        {
            var fornecedor = await _context.Fornecedor.FindAsync(id);
            if (fornecedor == null)
                return NotFound($"Fornecedor com ID {id} não encontrado.");
            return Ok(fornecedor);
        }

        [HttpPost]
        public async Task<IActionResult> AdicionarFornecedor([FromBody] Fornecedor novoFornecedor)
        {
            if (novoFornecedor == null)
                return BadRequest("Fornecedor não pode ser nulo.");

            _context.Fornecedor.Add(novoFornecedor);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterFornecedor), new { id = novoFornecedor.Id }, novoFornecedor);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> AtualizarFornecedor(int id, [FromBody] Fornecedor fornecedorAtualizado)
        {
            if (id != fornecedorAtualizado.Id)
                return BadRequest("ID do Fornecedor não corresponde aos dados fornecidos.");

            var fornecedorExistente = await _context.Fornecedor.FindAsync(id);
            if (fornecedorExistente == null)
                return NotFound($"Fornecedor com ID {id} não encontrado.");

            fornecedorExistente.Nome = fornecedorAtualizado.Nome;
            fornecedorExistente.Produtos = fornecedorAtualizado.Produtos;
            fornecedorExistente.quantidade = fornecedorAtualizado.quantidade;

            await _context.SaveChangesAsync();
            return Ok(fornecedorExistente);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> ExcluirFornecedor(int id)
        {
            var fornecedor = await _context.Fornecedor.FindAsync(id);
            if (fornecedor == null)
                return NotFound($"Fornecedor com ID {id} não encontrado.");

            _context.Fornecedor.Remove(fornecedor);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
