using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransacaoController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public TransacaoController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("Transações")]
        public async Task<IActionResult> ObterTodosAsTransacoes()
        {
            var transacao = await _context.Transacao.ToListAsync();
            return Ok(transacao);
        }

        [HttpGet("Transações/{id}")]
        public async Task<IActionResult> ObterTransacoesPorId(int id)
        {
            var transacao = await _context.Transacao.FindAsync(id);
            if (transacao == null)
                return NotFound($"Transação com ID {id} não encontrada.");
            return Ok(transacao);
        }

        [HttpPost("Adicionar Transação")]
        public async Task<IActionResult> CriarTransacao([FromBody] Transacao novaTransacao)
        {
            if (novaTransacao == null)
                return BadRequest("Dados da transação não podem ser nulos.");

            _context.Transacao.Add(novaTransacao);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterTransacoesPorId), new { id = novaTransacao.Id }, novaTransacao);
        }

        [HttpPut("Atualizar Transação/{id}")]
        public async Task<IActionResult> AtualizarTransacao(int id, [FromBody] Transacao transacaoAtualizada)
        {
            if (id != transacaoAtualizada.Id)
                return BadRequest("ID da transação não corresponde aos dados fornecidos.");

            var transacaoExistente = await _context.Transacao.FindAsync(id);
            if (transacaoExistente == null)
                return NotFound($"Transação com ID {id} não encontrada.");

            transacaoExistente.email = transacaoAtualizada.email;
            transacaoExistente.pais = transacaoAtualizada.pais;
            transacaoExistente.nome = transacaoAtualizada.nome;
            transacaoExistente.sobrenome = transacaoAtualizada.sobrenome;
            transacaoExistente.cep = transacaoAtualizada.cep;
            transacaoExistente.endereco = transacaoAtualizada.endereco;
            transacaoExistente.numero = transacaoAtualizada.numero;
            transacaoExistente.complemento = transacaoAtualizada.complemento;
            transacaoExistente.bairro = transacaoAtualizada.bairro;
            transacaoExistente.cidade = transacaoAtualizada.cidade;
            transacaoExistente.estado = transacaoAtualizada.estado;
            transacaoExistente.telefone = transacaoAtualizada.telefone;
            transacaoExistente.formadp = transacaoAtualizada.formadp;

            await _context.SaveChangesAsync();
            return Ok(transacaoExistente);
        }

        [HttpDelete("Deletar Transação/{id}")]
        public async Task<IActionResult> ExcluirTransacao(int id)
        {
            var transacao = await _context.Transacao.FindAsync(id);
            if (transacao == null)
                return NotFound($"Transação com ID {id} não encontrada.");

            _context.Transacao.Remove(transacao);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
