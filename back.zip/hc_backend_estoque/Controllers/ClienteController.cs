using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientesController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public ClientesController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("Clientes")]
        public async Task<IActionResult> ObterTodosClientes()
        {
            var clientes = await _context.Clientes.ToListAsync();
            return Ok(clientes);
        }

        [HttpGet("Clientes/{id}")]
        public async Task<IActionResult> ObterClientePorId(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);
            if (cliente == null)
                return NotFound($"Cliente com ID {id} não encontrado.");
            return Ok(cliente);
        }

        [HttpPost("AdicionarCliente")]
        public async Task<IActionResult> CriarCliente([FromBody] Clientes novoCliente)
        {
            if (novoCliente == null)
            {
                return BadRequest("Dados do cliente não podem ser nulos.");
            }

            // Adiciona o cliente ao contexto
            _context.Clientes.Add(novoCliente);

            // Salva as alterações no banco de dados
            await _context.SaveChangesAsync();

            // Verifica se o cliente foi realmente adicionado
            var clienteAdicionado = await _context.Clientes.FindAsync(novoCliente.Id);
            if (clienteAdicionado == null)
            {
                return StatusCode(500, "Erro ao cadastrar o cliente.");
            }

            // Retorna a mensagem de sucesso
            return Ok(new { Message = "Cliente cadastrado com sucesso!" });
        }

        [HttpPut("Atualizar Cliente/{id}")]
        public async Task<IActionResult> AtualizarCliente(int id, [FromBody] Clientes clienteAtualizado)
        {
            if (id != clienteAtualizado.Id)
                return BadRequest("ID do cliente não corresponde aos dados fornecidos.");

            var clienteExistente = await _context.Clientes.FindAsync(id);
            if (clienteExistente == null)
                return NotFound($"Cliente com ID {id} não encontrado.");

            clienteExistente.Nome = clienteAtualizado.Nome;
            clienteExistente.Email = clienteAtualizado.Email;
            clienteExistente.Telefone = clienteAtualizado.Telefone;
            clienteExistente.Senha = clienteAtualizado.Senha;

            await _context.SaveChangesAsync();
            return Ok(clienteExistente);
        }

        [HttpDelete("Deletar Cliente/{id}")]
        public async Task<IActionResult> ExcluirCliente(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);
            if (cliente == null)
                return NotFound($"Cliente com ID {id} não encontrado.");

            _context.Clientes.Remove(cliente);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Novo método para buscar cliente pelo e-mail
        [HttpGet("BuscarPorEmail/{email}")]
        public async Task<IActionResult> BuscarClientePorEmail(string email)
        {
            var cliente = await _context.Clientes.FirstOrDefaultAsync(c => c.Email == email);
            if (cliente == null)
                return NotFound($"Cliente com e-mail {email} não encontrado.");

            return Ok(cliente.Id); // Retorna apenas o ID do cliente
        }
    }
}
