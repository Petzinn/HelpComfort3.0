using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
 
 
namespace hc_backend_estoque.Controllers
{
 
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly HelpDBContext _context;
 
        public LoginController(HelpDBContext dbContext)
        {
            _context = dbContext;
        }
 
        [HttpPost("login")]
        public IActionResult Login([FromBody] Clientes clientes)
        {
            var user = _context.Clientes.FirstOrDefault(u => u.Email == clientes.Email && u.Senha == clientes.Senha);
            if (user == null)
            {
                return Unauthorized();
            }
         
            return Ok(new { Message = "Logado!", ClientId = clientes.Id });
        }
    }
}