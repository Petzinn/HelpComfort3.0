using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutoController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public ProdutoController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("produtos")]
        public async Task<IActionResult> ObterTodosOsProdutos()
        {
            var produtos = await _context.Produtos.ToListAsync();
            return Ok(produtos);
        }

        [HttpGet("produtos/{id}")]
        public async Task<IActionResult> ObterProdutoPorId(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto == null)
                return NotFound($"Produto com ID {id} não encontrado.");
            return Ok(produto);
        }

        [HttpPost("produtos")]
        public async Task<IActionResult> CriarProduto([FromBody] Produtos novoProduto)
        {
            _context.Produtos.Add(novoProduto);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterProdutoPorId), new { id = novoProduto.Id }, novoProduto);
        }

        [HttpPut("produtos/{id}")]
        public async Task<IActionResult> AtualizarProduto(int id, [FromBody] Produtos produtoAtualizado)
        {
            if (id != produtoAtualizado.Id)
                return BadRequest("ID do produto não corresponde aos dados fornecidos.");

            var produtoExistente = await _context.Produtos.FindAsync(id);
            if (produtoExistente == null)
                return NotFound($"Produto com ID {id} não encontrado.");

            produtoExistente.Nome = produtoAtualizado.Nome;
            produtoExistente.Descricao = produtoAtualizado.Descricao;
            produtoExistente.Preco = produtoAtualizado.Preco;
            produtoExistente.Tamanho = produtoAtualizado.Tamanho;
            produtoExistente.Estoque = produtoAtualizado.Estoque;
            

            await _context.SaveChangesAsync();
            return Ok(produtoExistente);
        }

        [HttpDelete("produtos/{id}")]
        public async Task<IActionResult> ExcluirProduto(int id)
        {
            var produto = await _context.Produtos.FindAsync(id);
            if (produto == null)
                return NotFound($"Produto com ID {id} não encontrado.");

            _context.Produtos.Remove(produto);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
