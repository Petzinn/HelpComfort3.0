using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;


namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EstoqueController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public EstoqueController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("Estoque")]
        public async Task<IActionResult> ObterTodosOsEstoques()
        {
            var estoque = await _context.Estoque.ToListAsync();
            return Ok(estoque);
        }

        [HttpGet("Estoque/{id}")]
        public async Task<IActionResult> ObterEstoquePorId(int id)
        {
            var estoque = await _context.Estoque.FindAsync(id);
            if (estoque == null)
                return NotFound($"Estoque com ID {id} não encontrado.");
            return Ok(estoque);
        }


        [HttpPost("Adicionar Estoque")]
        public async Task<IActionResult> CriarEstoque([FromBody] Estoque novoEstoque)
        {
            _context.Estoque.Add(novoEstoque);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterEstoquePorId), new { id = novoEstoque.Id }, novoEstoque);
        }

        [HttpPut("Buscar Estoque/{id}")]
        public async Task<IActionResult> AtualizarEstoque(int id, [FromBody] Estoque estoqueAtualizado)
        {
            if (id != estoqueAtualizado.Id)
                return BadRequest("ID do estoque não corresponde aos dados fornecidos.");

            var estoqueExistente = await _context.Estoque.FindAsync(id);
            if (estoqueExistente == null)
                return NotFound($"Estoque com ID {id} não encontrado.");

          
            estoqueExistente.Id = estoqueAtualizado.Id;
            estoqueExistente.Produtos = estoqueAtualizado.Produtos;
            estoqueExistente.Fornecedores = estoqueAtualizado.Fornecedores;
       

            await _context.SaveChangesAsync();
            return Ok(estoqueExistente);
        }

        [HttpDelete("Deletar Estoque/{id}")]
        public async Task<IActionResult> ExcluirEstoque(int id)
        {
            var estoque = await _context.Estoque.FindAsync(id);
            if (estoque == null)
                return NotFound($"Estoque com ID {id} não encontrado.");

            _context.Estoque.Remove(estoque);
            await _context.SaveChangesAsync();
            return NoContent();
        }


    }
}