using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FuncionarioController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public FuncionarioController(HelpDBContext context)
        {
            _context = context;
        }

        // Obter todos os funcionários
        [HttpGet("Funcionario")]
        public async Task<IActionResult> ObterTodosAsFuncionario()
        {
            var funcionarios = await _context.Funcionario.ToListAsync();
            return Ok(funcionarios);
        }

        // Obter funcionário por ID
        [HttpGet("Funcionario/{id}")]
        public async Task<IActionResult> ObterFuncionarioPorId(int id)
        {
            var funcionario = await _context.Funcionario.FindAsync(id);
            if (funcionario == null)
                return NotFound($"Funcionário com ID {id} não encontrado.");
            return Ok(funcionario);
        }

        // Adicionar novo funcionário
        [HttpPost("AdicionarFuncionario")]
        public async Task<IActionResult> CriarFuncionario([FromBody] Funcionario novoFuncionario)
        {
            if (novoFuncionario == null)
                return BadRequest("Dados do funcionário não podem ser nulos.");

            _context.Funcionario.Add(novoFuncionario);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterFuncionarioPorId), new { id = novoFuncionario.Id }, novoFuncionario);
        }

        // Atualizar funcionário existente
        [HttpPut("AtualizarFuncionario/{id}")]
        public async Task<IActionResult> AtualizarFuncionario(int id, [FromBody] Funcionario funcionarioAtualizado)
        {
            if (id != funcionarioAtualizado.Id)
                return BadRequest("ID do funcionário não corresponde aos dados fornecidos.");

            var funcionarioExistente = await _context.Funcionario.FindAsync(id);
            if (funcionarioExistente == null)
                return NotFound($"Funcionário com ID {id} não encontrado.");

            funcionarioExistente.Nome = funcionarioAtualizado.Nome;
            funcionarioExistente.Senha = funcionarioAtualizado.Senha;

            await _context.SaveChangesAsync();
            return Ok(funcionarioExistente);
        }

        // Excluir funcionário
        [HttpDelete("DeletarFuncionario/{id}")]
        public async Task<IActionResult> ExcluirFuncionario(int id)
        {
            var funcionario = await _context.Funcionario.FindAsync(id);
            if (funcionario == null)
                return NotFound($"Funcionário com ID {id} não encontrado.");

            _context.Funcionario.Remove(funcionario);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Login do funcionário (verifica se a senha corresponde à do banco de dados)
        [HttpPost("Login")]
        public async Task<IActionResult> LoginFuncionario([FromBody] Funcionario funcionarioLogin)
        {
            if (funcionarioLogin == null || string.IsNullOrEmpty(funcionarioLogin.Nome) || string.IsNullOrEmpty(funcionarioLogin.Senha))
            {
                return BadRequest("Nome ou senha não podem ser nulos.");
            }

            // Busca o funcionário pelo nome
            var funcionarioExistente = await _context.Funcionario
                                                     .FirstOrDefaultAsync(f => f.Nome == funcionarioLogin.Nome);

            if (funcionarioExistente == null)
            {
                return NotFound("Funcionário não encontrado.");
            }

            // Verifica se a senha está correta
            if (funcionarioExistente.Senha != funcionarioLogin.Senha)
            {
                return Unauthorized("Senha incorreta.");
            }

            // Retorna sucesso e os dados do funcionário se a autenticação for bem-sucedida
            return Ok(new { mensagem = "Login bem-sucedido", funcionario = funcionarioExistente });
        }
    }
}
