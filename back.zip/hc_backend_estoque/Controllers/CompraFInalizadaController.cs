using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;


namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompraFinalizadaController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public CompraFinalizadaController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("comprafinalizada")]
        public async Task<IActionResult> ObterCompraFinalizada()
        {
            var comprafinalizada = await _context.CompraFinalizada.ToListAsync();
            return Ok(comprafinalizada);
        }

        [HttpGet("comprafinalizada/{id}")]
        public async Task<IActionResult> ObterCompraFinalizada(int id)
        {
            var comprafinalizada = await _context.CompraFinalizada.FindAsync(id);
            if (comprafinalizada == null)
                return NotFound($"CompraFinalizada com ID {id} não encontrado.");
            return Ok(comprafinalizada);
        }


        [HttpPost("comprafinalizada")]
        public async Task<IActionResult> ObterCompraFinalizadaPorId([FromBody] CompraFinalizada novaComprafinalizada)
        {
            _context.CompraFinalizada.Add(novaComprafinalizada);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterCompraFinalizadaPorId), new { id = novaComprafinalizada.Id }, novaComprafinalizada);
        }

        [HttpPut("comprafinalizada/{id}")]
        public async Task<IActionResult> AtualizarComprafinalizada(int id, [FromBody] CompraFinalizada ComprafinalizadaAtualizada)
        {
            if (id != ComprafinalizadaAtualizada.Id)
                return BadRequest("ID da Comprafinalizada não corresponde aos dados fornecidos.");

            var comprafinalizadaExistente = await _context.CompraFinalizada.FindAsync(id);
            if (comprafinalizadaExistente == null)
                return NotFound($"Comprafinalizada com ID {id} não encontrado.");

          
            comprafinalizadaExistente.Id = ComprafinalizadaAtualizada.Id;
            comprafinalizadaExistente.Produto2 = ComprafinalizadaAtualizada.Produto2;
            comprafinalizadaExistente.Valor2 = ComprafinalizadaAtualizada.Valor2;
       

            await _context.SaveChangesAsync();
            return Ok(comprafinalizadaExistente);
        }

        [HttpDelete("comprafinalizada/{id}")]
        public async Task<IActionResult> ExcluirComprafinalizada(int id)
        {
            var comprafinalizada = await _context.CompraFinalizada.FindAsync(id);
            if (comprafinalizada == null)
                return NotFound($"Comprafinalizada com ID {id} não encontrado.");

            _context.CompraFinalizada.Remove(comprafinalizada);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}