using Microsoft.AspNetCore.Mvc;
using hc_backend_estoque.Context;
using hc_backend_estoque.Entities;
using Microsoft.EntityFrameworkCore;

namespace hc_backend_estoque.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase
    {
        private readonly HelpDBContext _context;

        public CategoriaController(HelpDBContext context)
        {
            _context = context;
        }

        [HttpGet("categoria")]
        public async Task<IActionResult> ObterCategoria()
        {
            var categoria = await _context.Categoria.ToListAsync();
            return Ok(categoria);
        }

        [HttpGet("categoria/{id}")]
        public async Task<IActionResult> ObterCategoria(int id)
        {
            var categoria = await _context.Categoria.FindAsync(id);
            if (categoria == null)
                return NotFound($"Categoria com ID {id} não encontrado.");
            return Ok(categoria);
        }


        [HttpPost("categoria")]
        public async Task<IActionResult> ObterCategoriaPorId([FromBody] Categoria novaCategoria)
        {
            _context.Categoria.Add(novaCategoria);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(ObterCategoriaPorId), new { id = novaCategoria.Id }, novaCategoria);
        }

        [HttpPut("categoria/{id}")]
        public async Task<IActionResult> AtualizarCategoria(int id, [FromBody] Categoria CategoriaAtualizada)
        {
            if (id != CategoriaAtualizada.Id)
                return BadRequest("ID da Categoria não corresponde aos dados fornecidos.");

            var categoriaExistente = await _context.Categoria.FindAsync(id);
            if (categoriaExistente == null)
                return NotFound($"Categoria com ID {id} não encontrado.");

          
            categoriaExistente.Id = CategoriaAtualizada.Id;
            categoriaExistente.Modelo = CategoriaAtualizada.Modelo;
            categoriaExistente.Tecido = CategoriaAtualizada.Tecido;
       

            await _context.SaveChangesAsync();
            return Ok(categoriaExistente);
        }

        [HttpDelete("categoria/{id}")]
        public async Task<IActionResult> ExcluirCategoria(int id)
        {
            var categoria = await _context.Categoria.FindAsync(id);
            if (categoria == null)
                return NotFound($"Categoria com ID {id} não encontrado.");

            _context.Categoria.Remove(categoria);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}